public class Texte extends Element
{

	public Texte(int x, int y, String texte)
	{
		super(x, y, texte);
	}

	public String   getType    () { return "Texte";       }


}

