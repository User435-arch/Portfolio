import java.util.List;
import java.util.ArrayList;

public class Diapositive
{
	private List<Element> ensElement;

	public Diapositive ()
	{
		this.ensElement = new ArrayList<Element>();
	}

	public boolean ajouterElement( Element elt )
	{
		if(elt == null) {return false;}

		if(elt.getClass().getName().equals("Titre") && ! this.ensElement.isEmpty())
			return false;

		this.ensElement.add(elt);

		return true;
	}

	public Element getTitre()
	{
		for(Element e : this.ensElement)
		{
			if(e.getClass().getName().equals("Titre")) { return e; }
		}

		return null;
	}


	public String toString()
	{
		String sRet = "";

		for ( Element e : this.ensElement )
		{
			sRet += "   " + e.toString() + "\n";
		}

		return sRet;
	}

}