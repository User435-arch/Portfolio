public class TestDiaporama
{
	public static void main(String[] a)
	{
		Diaporama pres1 = new Diaporama();

		Diapositive tmpDiap;

		// Création de la première diapositive
		tmpDiap = new Diapositive();

		tmpDiap.ajouterElement ( Titre.creerTitre ( 10,10, "Introduction" ) );
		tmpDiap.ajouterElement ( new Texte ( 10,20, "Ceci est une introduction à une histoire fort fort lointaine"   ) );

		pres1.ajouterDiapo ( tmpDiap );


		// Création de la deuxième diapositive
		tmpDiap = new Diapositive();

		tmpDiap.ajouterElement ( Titre.creerTitre ( 10,10, "Un titre bcp trop long" ) );
		tmpDiap.ajouterElement ( Titre.creerTitre ( 10,10, "Le Départ"              ) );
		tmpDiap.ajouterElement ( new Texte ( 10,20, "Nous partîmes dans le grand ouest, à la découverte d'un monde nouveau" ) );
		tmpDiap.ajouterElement ( Titre.creerTitre ( 10,10, "Un 2ème titre"          ) );
		tmpDiap.ajouterElement ( new Image ( 10,30, "ouest.png"              ) );

		pres1.ajouterDiapo ( tmpDiap );



		// Création de la troisième diapositive
		tmpDiap = new Diapositive();

		tmpDiap.ajouterElement ( Titre.creerTitre ( 10,10, "Le Retour"                      ) );
		tmpDiap.ajouterElement ( new Texte ( 10,10, "Nous sommes revenus dans l'est" ) );
		tmpDiap.ajouterElement ( new Image ( 10,30, "est.png", 2.5                   ) );
		tmpDiap.ajouterElement ( new Texte ( 10,10, "C'était un beau voyage"         ) );


		pres1.ajouterDiapo ( tmpDiap );



		// Affichage du Diaporama
		System.out.println ( "Affichage du Diaporama\n" );
		System.out.println ( pres1   );


		// Affichage du fil d'Ariane
		System.out.println ( "\n\nAffichage du fil d'Ariane\n" );
		System.out.println ( pres1.filAriane()   );

	}
}