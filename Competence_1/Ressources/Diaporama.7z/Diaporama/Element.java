public abstract class Element
{
    private  Position position;
    private  String   texte;

    public Element(int x, int y, String texte)
    {
        this.position = new Position ( x, y );
        this.texte    = texte;
    }

    public Position getPosition() { return this.position; }
    public String   getTexte   () { return this.texte;    }
    public abstract String   getType    ();

    public String toString()
    {
        return  String.format ( "%-8s", this.getType() ) + this.position.toString() + " :" + this.texte;
    }
}
