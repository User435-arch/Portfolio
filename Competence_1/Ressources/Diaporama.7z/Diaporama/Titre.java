public class Titre extends Element
{
	private Titre ( int x, int y, String texte )
	{
		super(x, y, texte);
	}

	public static Titre creerTitre( int x, int y, String texte )
	{
		if(texte.length() < 20) {return new Titre(x, y, texte);}
		return null;
	}

	public String   getType    () { return "Titre";       }

}

