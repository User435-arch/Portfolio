public class Image extends Element
{
	private Double   zoom;

	public Image(int x, int y, String texte)
	{
		super(x, y, texte);
		this.zoom     = 1.0;
	}

	public Image(int x, int y, String texte, double zoom )
	{
		super(x, y, texte);
		this.zoom     = zoom;
	}

	public String getType() { return "Image"; }

	public String toString()
	{
		return  super.toString() + "  (zoom : " + this.zoom + ")";
	}

}

