import java.util.List;
import java.util.ArrayList;

public class Diaporama
{
	private static final int NB_DIAPO_MAX = 15;

	private int couleurFond;
	private int couleurFont;
	private int tailleTitre;
	private int tailleTexte;

	private List<Diapositive>  ensDiapo;

	public Diaporama ()
	{
		this ( 16_250_333, 18_457, 22, 18 );
	}


	public Diaporama ( int couleurFond, int couleurFont, int tailleTitre, int tailleTexte )
	{
		this.couleurFond = couleurFond;
		this.couleurFont = couleurFont;
		this.tailleTitre = tailleTitre;
		this.tailleTexte = tailleTexte;

		this.ensDiapo = new ArrayList<>();
	}


	public void ajouterDiapo ( Diapositive diap )
	{
		if(this.ensDiapo.size() == Diaporama.NB_DIAPO_MAX) {return;}

		this.ensDiapo.add(diap);
	}



	public String filAriane()
	{
		int    tot  = this.ensDiapo.size();
		String texte;
		String sRet = "Fil d'Ariane\n";

		for(Diapositive d : this.ensDiapo)
			System.out.println(d.getTitre());

		return sRet;
	}

	public String toString()
	{
		int    tot  = this.ensDiapo.size();
		String sRet = "";

		for ( int cpt=0; cpt < tot; cpt++ )
		{
			sRet += "Diapo " + String.format("%02d", cpt+1) + "/" + String.format("%02d", tot) + "\n";

			sRet += this.ensDiapo.get(cpt).toString();
		}

		return sRet;
	}
}